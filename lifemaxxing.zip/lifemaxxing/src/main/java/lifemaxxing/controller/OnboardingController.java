package lifemaxxing.controller;

import jakarta.servlet.http.HttpSession;
import lifemaxxing.dto.FormError;
import lifemaxxing.dto.OnboardingForm;
import lifemaxxing.model.FitnessGoal.GoalType;
import lifemaxxing.model.User;
import lifemaxxing.model.UserProfile.ExperienceLevel;
import lifemaxxing.model.UserProfile.Gender;
import lifemaxxing.service.OnboardingService;
import lifemaxxing.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

// Spørgeskemaet. Bruges både første gang og når brugeren vil rette sine svar
@Controller
public class OnboardingController {

    private final UserService userService;
    private final OnboardingService onboardingService;

    public OnboardingController(UserService userService, OnboardingService onboardingService) {
        this.userService = userService;
        this.onboardingService = onboardingService;
    }

    // Valgmulighederne til radio-knapperne i html
    @ModelAttribute("genders")
    public Gender[] genders() { return Gender.values(); }

    @ModelAttribute("levels")
    public ExperienceLevel[] levels() { return ExperienceLevel.values(); }

    @ModelAttribute("goalTypes")
    public GoalType[] goalTypes() { return GoalType.values(); }

    @ModelAttribute("physicalOptions")
    public List<String> physicalOptions() { return List.of("Stærkere", "Mere toned", "Eksplosiv", "Større"); }

    @ModelAttribute("durations")
    public List<Integer> durations() { return List.of(30, 45, 60, 90); }

    @GetMapping("/onboarding")
    public String showForm(HttpSession session, Model model) {
        User user = userService.findById(SessionUtil.getUserId(session)).orElse(null);
        if (user == null) {
            return "redirect:/login";
        }

        model.addAttribute("form", onboardingService.toForm(user));
        model.addAttribute("editing", user.hasCompletedOnboarding());
        return "onboarding";
    }

    @PostMapping("/onboarding")
    public String submit(@ModelAttribute("form") OnboardingForm form, BindingResult binding,
                         HttpSession session, Model model) {
        User user = userService.findById(SessionUtil.getUserId(session)).orElse(null);
        if (user == null) {
            return "redirect:/login";
        }
        model.addAttribute("editing", user.hasCompletedOnboarding());

        // Bogstaver i et talfelt o.l. fanges her før vi når til servicen
        if (binding.hasErrors()) {
            model.addAttribute("error", "Et eller flere felter er ikke udfyldt korrekt. Brug kun tal i tal-felterne.");
            model.addAttribute("errorField", binding.getFieldError() != null ? binding.getFieldError().getField() : "");
            return "onboarding";
        }

        FormError error = onboardingService.validate(form);
        if (error != null) {
            model.addAttribute("error", error.getMessage());
            model.addAttribute("errorField", error.getField());
            return "onboarding";
        }

        onboardingService.complete(user, form);
        return "redirect:/dashboard";
    }
}
