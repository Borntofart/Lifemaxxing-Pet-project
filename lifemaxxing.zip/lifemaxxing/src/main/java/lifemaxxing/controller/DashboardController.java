package lifemaxxing.controller;

import jakarta.servlet.http.HttpSession;
import lifemaxxing.model.User;
import lifemaxxing.service.DashboardService;
import lifemaxxing.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class DashboardController {

    private final UserService userService;
    private final DashboardService dashboardService;

    public DashboardController(UserService userService, DashboardService dashboardService) {
        this.userService = userService;
        this.dashboardService = dashboardService;
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        User user = userService.findById(SessionUtil.getUserId(session)).orElse(null);
        if (user == null) {
            return "redirect:/login";
        }
        if (!user.hasCompletedOnboarding()) {
            return "redirect:/onboarding";
        }

        model.addAttribute("view", dashboardService.buildView(user));
        return "dashboard";
    }

    @PostMapping("/dashboard/vaegt")
    public String addWeighIn(@RequestParam(required = false) Float weightKg,
                             HttpSession session, RedirectAttributes redirect) {
        User user = userService.findById(SessionUtil.getUserId(session)).orElse(null);
        if (user == null) {
            return "redirect:/login";
        }
        if (!user.hasCompletedOnboarding()) {
            return "redirect:/onboarding";
        }

        String error = dashboardService.registerWeighIn(user, weightKg);
        if (error != null) {
            redirect.addFlashAttribute("weighInError", error);
        } else {
            redirect.addFlashAttribute("weighInSuccess", "Vægten er gemt og din kostplan er opdateret.");
        }
        return "redirect:/dashboard";
    }
}
