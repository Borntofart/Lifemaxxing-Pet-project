package lifemaxxing.controller;

import jakarta.servlet.http.HttpSession;
import lifemaxxing.dto.FormError;
import lifemaxxing.dto.LoginForm;
import lifemaxxing.dto.RegisterForm;
import lifemaxxing.model.User;
import lifemaxxing.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/")
    public String home(HttpSession session) {
        return SessionUtil.isLoggedIn(session) ? "redirect:/dashboard" : "redirect:/login";
    }

    @GetMapping("/login")
    public String showLogin(@RequestParam(required = false) String created,
                            @RequestParam(required = false) String logout,
                            HttpSession session, Model model) {
        if (SessionUtil.isLoggedIn(session)) {
            return "redirect:/dashboard";
        }

        LoginForm form = new LoginForm();
        if (created != null) {
            form.setUsername(created);
            model.addAttribute("success", "Brugeren \"" + created + "\" er oprettet. Log ind herunder.");
        } else if (logout != null) {
            model.addAttribute("success", "Du er nu logget ud.");
        }
        model.addAttribute("form", form);
        return "login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute("form") LoginForm form, HttpSession session, Model model) {
        if (form.getUsername() == null || form.getUsername().isBlank()) {
            return loginError(model, "username", "Du skal indtaste et brugernavn.");
        }
        if (form.getPassword() == null || form.getPassword().isEmpty()) {
            return loginError(model, "password", "Du skal indtaste et kodeord.");
        }

        Optional<User> user = userService.login(form.getUsername(), form.getPassword());
        if (user.isEmpty()) {
            return loginError(model, "both", "Forkert brugernavn eller kodeord.");
        }

        SessionUtil.login(session, user.get().getId());

        // Første gang skal brugeren igennem spørgeskemaet
        return user.get().hasCompletedOnboarding() ? "redirect:/dashboard" : "redirect:/onboarding";
    }

    @GetMapping("/register")
    public String showRegister(Model model) {
        model.addAttribute("form", new RegisterForm());
        return "register";
    }

    @PostMapping("/register")
    public String register(@ModelAttribute("form") RegisterForm form, Model model) {
        FormError error = userService.validateRegistration(form);
        if (error != null) {
            model.addAttribute("error", error.getMessage());
            model.addAttribute("errorField", error.getField());
            return "register";
        }

        User user = userService.register(form);
        return "redirect:/login?created=" + user.getUsername();
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login?logout=1";
    }

    private String loginError(Model model, String field, String message) {
        model.addAttribute("error", message);
        model.addAttribute("errorField", field);
        return "login";
    }
}
