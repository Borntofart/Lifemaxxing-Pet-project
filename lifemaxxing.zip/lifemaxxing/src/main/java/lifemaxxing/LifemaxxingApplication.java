package lifemaxxing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifemaxxingApplication {

    public static void main(String[] args) {
        SpringApplication.run(LifemaxxingApplication.class, args);
    }
}
